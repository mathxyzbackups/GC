/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "svd.h"
#include "eigen_sym.h"
#include "ops.h"

namespace math21 {
    using namespace numerical_recipes;

    // see http://fourier.eng.hmc.edu/e176/lectures/NM/node8.html
    // A = U*W*V.t
    void math21_operator_svd_real(const MatR &M, MatR &u, VecR &w, MatR &v) {
        ShiftedMatR A;
        A.setTensor(M);
        SVD svd(A);
        u.copyFrom(svd.get_u().getTensor());
        w.copyFrom(svd.get_w().getTensor());
        v.copyFrom(svd.get_v().getTensor());
    }

    // see https://personalpages.manchester.ac.uk/staff/timothy.f.cootes/MathsMethodsNotes/L3_linear_algebra3.pdf
    NumB math21_operator_svd_solve_linear_equation(const MatR &A, const MatR &B, MatR &X) {
        NumN m, n, p;
        m = A.nrows();
        n = A.ncols();
        p = B.ncols();
        MATH21_ASSERT(m >= n, "Solving under-determined linear systems not supported!");
        ShiftedMatR As, Bs, Xs;
        As.setTensor(A);
        Bs.setTensor(B);
        if (B.dims() == 1) {
            Xs.setSize(n);
        } else {
            Xs.setSize(n, p);
        }
        numerical_recipes::SVD svd(As);
        if (B.dims() == 1) {
            svd.solve_vec(Bs, Xs);
        } else {
            svd.solve_mat(Bs, Xs);
        }
        X = Xs.getTensor();
        return 1;
    }

    void math21_operator_eigen_real_sys_descending(const MatR &M, VecR &Lambda, MatR &X) {
        ShiftedMatR A;
        A.setTensor(M);
        Symmeig module(A);
//        Jacobi module(A);
        Lambda.copyFrom(module.get_eigenvalues().getTensor());
        X.copyFrom(module.get_eigenvectors().getTensor());
    }

    void math21_operator_eigen_real_sys_ascending(const MatR &M, VecR &Lambda, MatR &X) {
        ShiftedMatR A;
        A.setTensor(M);
        Symmeig module(A);
//        Jacobi module(A);
        Lambda.copyFrom(module.get_eigenvalues().getTensor());
        X.copyFrom(module.get_eigenvectors().getTensor());
        math21_operator_matrix_reverse_x_axis(Lambda);
        math21_operator_matrix_reverse_y_axis(X);
    }
}