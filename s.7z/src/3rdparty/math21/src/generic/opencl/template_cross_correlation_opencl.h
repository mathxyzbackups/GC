/* Copyright 2015 The math21 Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#pragma once

#include "inner_cc.h"
#include "../../algebra/files.h"
#include "common.h"

#ifdef MATH21_FLAG_USE_OPENCL

const static std::string kernel_file = "generic_cross_correlation.kl";
static std::shared_ptr<m21clprogram> program = NULL;

#define MATH21_TEMPLATE_BEFORE() \
if (program == NULL) { \
program = math21_opencl_build_program_from_file(kernel_file, math21_opencl_options_for_program<T>()); \
}

// d: dilation, k: kernel, p: pad, s: stride
template<typename T>
void math21_template_cross_correlation_X_to_X_prime_opencl(
        PointerVoidInputWrapper X, PointerVoidWrapper X_prime,
        int nch_X, int nr_X, int nc_X,
        int nr_k, int nc_k,
        int nr_p, int nc_p,
        int nr_s, int nc_s,
        int nr_d, int nc_d) {
    int nr_k_ext = (nr_k - 1) * nr_d + 1;
    int nc_k_ext = (nc_k - 1) * nc_d + 1;
    int nc_X_prime_1 = (nr_X + 2 * nr_p - nr_k_ext) / nr_s + 1;
    int nc_X_prime_2 = (nc_X + 2 * nc_p - nc_k_ext) / nc_s + 1;
    int n = nch_X * nc_X_prime_1 * nc_X_prime_2;

    MATH21_TEMPLATE_BEFORE();
    std::string kernelName;
    kernelName = math21_opencl_template_kernelName_1<T>(
                "math21_template_cross_correlation_X_to_X_prime_opencl_kernel");


    cl_kernel kernel = math21_opencl_getKernel(program, kernelName);

    math21_opencl_checkError(clSetKernelArg(kernel, 0, sizeof(int), (const void *) &n));
    math21_opencl_checkError(clSetKernelArg(kernel, 1, sizeof(cl_mem), (const void *) &X.buffer));
    math21_opencl_checkError(clSetKernelArg(kernel, 2, sizeof(cl_mem), (const void *) &X_prime.buffer));
    math21_opencl_checkError(clSetKernelArg(kernel, 3, sizeof(int), (const void *) &nr_X));
    math21_opencl_checkError(clSetKernelArg(kernel, 4, sizeof(int), (const void *) &nc_X));
    math21_opencl_checkError(clSetKernelArg(kernel, 5, sizeof(int), (const void *) &nr_k));
    math21_opencl_checkError(clSetKernelArg(kernel, 6, sizeof(int), (const void *) &nc_k));
    math21_opencl_checkError(clSetKernelArg(kernel, 7, sizeof(int), (const void *) &nr_p));
    math21_opencl_checkError(clSetKernelArg(kernel, 8, sizeof(int), (const void *) &nc_p));
    math21_opencl_checkError(clSetKernelArg(kernel, 9, sizeof(int), (const void *) &nr_s));
    math21_opencl_checkError(clSetKernelArg(kernel, 10, sizeof(int), (const void *) &nc_s));
    math21_opencl_checkError(clSetKernelArg(kernel, 11, sizeof(int), (const void *) &nr_d));
    math21_opencl_checkError(clSetKernelArg(kernel, 12, sizeof(int), (const void *) &nc_d));
    math21_opencl_checkError(clSetKernelArg(kernel, 13, sizeof(int), (const void *) &nc_X_prime_1));
    math21_opencl_checkError(clSetKernelArg(kernel, 14, sizeof(int), (const void *) &nc_X_prime_2));

    MATH21_TEMPLATE_AFTER();
}

// d: dilation, k: kernel, p: pad, s: stride
template<typename T>
void math21_template_cross_correlation_dX_prime_to_dX_opencl(
        PointerVoidInputWrapper dX_prime, PointerVoidWrapper dX,
        int nch_X, int nr_X, int nc_X,
        int nr_k, int nc_k,
        int nr_p, int nc_p,
        int nr_s, int nc_s,
        int nr_d, int nc_d) {
    int nr_k_ext = (nr_k - 1) * nr_d + 1;
    int nc_k_ext = (nc_k - 1) * nc_d + 1;
    int nc_X_prime_1 = (nr_X + 2 * nr_p - nr_k_ext) / nr_s + 1;
    int nc_X_prime_2 = (nc_X + 2 * nc_p - nc_k_ext) / nc_s + 1;
    int n = nch_X * nr_X * nc_X;

    MATH21_TEMPLATE_BEFORE();
    std::string kernelName;
    if (nr_d == 1 && nc_d == 1) {
    kernelName = math21_opencl_template_kernelName_1<T>(
                "math21_template_cross_correlation_dX_prime_to_dX_without_dilation_addto_opencl_kernel");
    }else{
        kernelName = math21_opencl_template_kernelName_1<T>(
                "math21_template_cross_correlation_dX_prime_to_dX_addto_opencl_kernel");
    }

    cl_kernel kernel = math21_opencl_getKernel(program, kernelName);

    math21_opencl_checkError(clSetKernelArg(kernel, 0, sizeof(int), (const void *) &n));
    math21_opencl_checkError(clSetKernelArg(kernel, 1, sizeof(cl_mem), (const void *) &dX_prime.buffer));
    math21_opencl_checkError(clSetKernelArg(kernel, 2, sizeof(cl_mem), (const void *) &dX.buffer));
    math21_opencl_checkError(clSetKernelArg(kernel, 3, sizeof(int), (const void *) &nr_X));
    math21_opencl_checkError(clSetKernelArg(kernel, 4, sizeof(int), (const void *) &nc_X));
    math21_opencl_checkError(clSetKernelArg(kernel, 5, sizeof(int), (const void *) &nr_k));
    math21_opencl_checkError(clSetKernelArg(kernel, 6, sizeof(int), (const void *) &nc_k));
    math21_opencl_checkError(clSetKernelArg(kernel, 7, sizeof(int), (const void *) &nr_p));
    math21_opencl_checkError(clSetKernelArg(kernel, 8, sizeof(int), (const void *) &nc_p));
    math21_opencl_checkError(clSetKernelArg(kernel, 9, sizeof(int), (const void *) &nr_s));
    math21_opencl_checkError(clSetKernelArg(kernel, 10, sizeof(int), (const void *) &nc_s));

    if (nr_d == 1 && nc_d == 1){
        math21_opencl_checkError(clSetKernelArg(kernel, 11, sizeof(int), (const void *) &nc_X_prime_1));
    math21_opencl_checkError(clSetKernelArg(kernel, 12, sizeof(int), (const void *) &nc_X_prime_2));
    }else{
        math21_opencl_checkError(clSetKernelArg(kernel, 11, sizeof(int), (const void *) &nr_d));
    math21_opencl_checkError(clSetKernelArg(kernel, 12, sizeof(int), (const void *) &nc_d));
    math21_opencl_checkError(clSetKernelArg(kernel, 13, sizeof(int), (const void *) &nc_X_prime_1));
    math21_opencl_checkError(clSetKernelArg(kernel, 14, sizeof(int), (const void *) &nc_X_prime_2));
    }

    MATH21_TEMPLATE_AFTER();
}

#endif