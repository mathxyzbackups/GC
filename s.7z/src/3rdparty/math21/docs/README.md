# generate docs using Sphinx
# https://docs.readthedocs.io